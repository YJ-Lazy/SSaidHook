# SSaidHook - LSPosed Module

可视化配置并 Hook 目标应用的 `Settings.Secure.ANDROID_ID` (SSAID)。

## 功能
- 输入目标包名
- 输入或随机生成 16 位 SSAID
- 配置持久化（通过 SharedPreferences + XSharedPreferences）
- LSPosed Hook

## 如何构建 APK

1. 用 **Android Studio** 打开本项目根目录
2. 等待 Gradle 同步完成
3. Build → Build Bundle(s) / APK(s) → Build APK(s)
4. 生成的 APK 位于 `app/build/outputs/apk/debug/app-debug.apk`

或者使用命令行：

```bash
./gradlew assembleDebug
```

## 安装与使用

1. 安装生成的 APK
2. 在 **LSPosed Manager** 中启用本模块，并勾选作用域（至少包含目标应用）
3. 打开本模块 APP，输入目标包名和想要的 SSAID（或点随机生成），点击保存
4. 强制停止目标应用后重新打开，SSAID 即被 Hook

## 注意事项

- 需要已安装并激活 **LSPosed**（推荐 Zygisk 版本）
- `xposedsharedprefs` 已声明，确保 XSharedPreferences 能正确读取
- 目标应用必须在 LSPosed 作用域内
- Android 8.0+ 推荐使用 MODE_PRIVATE + LSPosed 的共享偏好机制

## 原始模板说明

本项目基于提供的最小模板补全了完整的 Android Gradle 工程结构。
