package com.example.ssaidhook;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Toast;

import java.util.UUID;

public class MainActivity extends Activity {
    private EditText pkgEdit;
    private EditText idEdit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(48, 48, 48, 48);

        pkgEdit = new EditText(this);
        pkgEdit.setHint("目标包名 (例如 com.example.app)");
        pkgEdit.setSingleLine(true);

        idEdit = new EditText(this);
        idEdit.setHint("SSAID (16位十六进制)");
        idEdit.setSingleLine(true);

        Button saveBtn = new Button(this);
        saveBtn.setText("保存配置");

        Button randomBtn = new Button(this);
        randomBtn.setText("随机生成 SSAID");

        layout.addView(pkgEdit);
        layout.addView(idEdit);
        layout.addView(saveBtn);
        layout.addView(randomBtn);
        setContentView(layout);

        SharedPreferences sp = getSharedPreferences("ssaidhook_config", MODE_WORLD_READABLE);
        // Note: MODE_WORLD_READABLE is deprecated but needed for older Xposed;
        // LSPosed uses xposedsharedprefs meta-data + XSharedPreferences.

        pkgEdit.setText(sp.getString("package", ""));
        idEdit.setText(sp.getString("android_id", ""));

        saveBtn.setOnClickListener(v -> {
            String pkg = pkgEdit.getText().toString().trim();
            String id = idEdit.getText().toString().trim();
            sp.edit()
                    .putString("package", pkg)
                    .putString("android_id", id)
                    .apply();
            Toast.makeText(this, "配置已保存", Toast.LENGTH_SHORT).show();
        });

        randomBtn.setOnClickListener(v -> {
            String randomId = UUID.randomUUID().toString().replace("-", "").substring(0, 16);
            idEdit.setText(randomId);
        });
    }
}
