package com.example.ssaidhook;

import android.provider.Settings;
import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XSharedPreferences;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {
    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        XSharedPreferences prefs = new XSharedPreferences("com.example.ssaidhook", "ssaidhook_config");
        prefs.reload();

        String targetPackage = prefs.getString("package", "");
        String fakeSsaid = prefs.getString("android_id", "");

        if (targetPackage.isEmpty() || fakeSsaid.isEmpty()) {
            return;
        }

        if (!lpparam.packageName.equals(targetPackage)) {
            return;
        }

        XposedHelpers.findAndHookMethod(
                Settings.Secure.class,
                "getString",
                android.content.ContentResolver.class,
                String.class,
                new XC_MethodHook() {
                    @Override
                    protected void beforeHookedMethod(MethodHookParam param) {
                        if (Settings.Secure.ANDROID_ID.equals(param.args[1])) {
                            param.setResult(fakeSsaid);
                        }
                    }
                }
        );
    }
}
